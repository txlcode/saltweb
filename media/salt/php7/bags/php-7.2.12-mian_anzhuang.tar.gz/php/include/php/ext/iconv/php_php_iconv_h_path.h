#define PHP_ICONV_H_PATH </usr/local/include/iconv.h>
